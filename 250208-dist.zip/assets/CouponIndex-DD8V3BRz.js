import{j as o}from"./index-DI0hZm8z.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
