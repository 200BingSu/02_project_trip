import{j as t,O as e}from"./index-DI0hZm8z.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
