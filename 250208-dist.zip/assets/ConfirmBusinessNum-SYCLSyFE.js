import{j as s}from"./index-DI0hZm8z.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
