import{j as s,O as t}from"./index-DI0hZm8z.js";const r=()=>s.jsx("div",{className:"w-full",children:s.jsx(t,{})});export{r as default};
