import{j as s}from"./index-DI0hZm8z.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
