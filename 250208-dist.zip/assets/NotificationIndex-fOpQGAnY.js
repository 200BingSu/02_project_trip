import{j as t}from"./index-DI0hZm8z.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
