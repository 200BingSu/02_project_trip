import{j as t}from"./index-CZv3VRYh.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
