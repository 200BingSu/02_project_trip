import{j as s,O as t}from"./index-CZv3VRYh.js";const r=()=>s.jsx("div",{className:"w-full",children:s.jsx(t,{})});export{r as default};
