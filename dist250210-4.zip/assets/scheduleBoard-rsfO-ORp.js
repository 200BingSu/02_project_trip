import{j as t,O as e}from"./index-CZv3VRYh.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
