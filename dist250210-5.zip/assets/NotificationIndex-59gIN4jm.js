import{j as t}from"./index-4vVrLCEc.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
