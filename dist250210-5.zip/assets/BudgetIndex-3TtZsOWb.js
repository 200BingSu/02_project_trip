import{j as e}from"./index-4vVrLCEc.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
