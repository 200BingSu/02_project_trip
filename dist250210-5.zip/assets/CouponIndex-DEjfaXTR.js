import{j as o}from"./index-4vVrLCEc.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
