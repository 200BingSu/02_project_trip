import{j as s}from"./index-4vVrLCEc.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
