import{j as s}from"./index-4vVrLCEc.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
