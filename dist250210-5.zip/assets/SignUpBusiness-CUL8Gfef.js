import{j as s}from"./index-4vVrLCEc.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
