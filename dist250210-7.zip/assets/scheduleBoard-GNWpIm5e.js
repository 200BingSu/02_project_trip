import{j as t,O as e}from"./index-DCiO2zt9.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
