import{j as s}from"./index-DCiO2zt9.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
