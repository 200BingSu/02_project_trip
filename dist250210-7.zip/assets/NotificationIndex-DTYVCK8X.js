import{j as t}from"./index-DCiO2zt9.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
