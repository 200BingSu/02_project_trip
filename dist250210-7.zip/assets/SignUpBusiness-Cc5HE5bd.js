import{j as s}from"./index-DCiO2zt9.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
