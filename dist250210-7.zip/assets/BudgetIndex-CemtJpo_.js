import{j as e}from"./index-DCiO2zt9.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
