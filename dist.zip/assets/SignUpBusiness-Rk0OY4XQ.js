import{j as s}from"./index-YXlYzo5D.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
