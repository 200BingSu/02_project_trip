import{j as o}from"./index-ztVTG9lp.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
