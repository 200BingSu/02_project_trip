import{j as s}from"./index-DyS74CsT.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
