import{j as t,O as e}from"./index-Cwx4I7Vi.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
