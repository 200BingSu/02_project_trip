function r(e){return["small","middle","large"].includes(e)}function a(e){return e?typeof e=="number"&&!Number.isNaN(e):!1}export{a,r as i};
