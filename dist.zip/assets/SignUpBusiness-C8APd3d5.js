import{j as s}from"./index-Ci2k4qFh.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
