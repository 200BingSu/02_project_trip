import{f as o}from"./index-DlYLfxzI.js";const e=s=>{const[,,,,r]=o();return r?`${s}-css-var`:""};export{e as u};
