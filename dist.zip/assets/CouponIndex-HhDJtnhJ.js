import{j as o}from"./index-LV_9s5-1.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
