import{j as t}from"./index-C02P6yB2.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
