import{j as o}from"./index-Cw-8d7Yh.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
