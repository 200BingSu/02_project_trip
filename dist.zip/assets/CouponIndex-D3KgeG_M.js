import{j as o}from"./index-DyS74CsT.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
