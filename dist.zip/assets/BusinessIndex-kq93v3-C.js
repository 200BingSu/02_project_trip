import{j as s}from"./index-lSgSIVq0.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
