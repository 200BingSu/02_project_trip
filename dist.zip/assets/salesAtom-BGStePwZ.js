import{f as s}from"./index-DyS74CsT.js";const e=s({key:"salesAtom",default:{sumMonth1:"0"}});export{e as s};
