import{j as s,O as t}from"./index-BDvp6vJ-.js";const e=()=>s.jsx("div",{children:s.jsx(t,{})});export{e as default};
