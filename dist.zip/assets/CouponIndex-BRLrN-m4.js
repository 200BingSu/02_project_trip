import{j as o}from"./index-Cwx4I7Vi.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
