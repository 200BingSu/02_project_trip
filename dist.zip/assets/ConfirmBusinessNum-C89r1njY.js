import{j as s}from"./index-BDH47TWw.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
