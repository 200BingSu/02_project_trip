import{j as e}from"./index-Cwx4I7Vi.js";const t=()=>e.jsx("div",{children:"ReviewIndex"});export{t as default};
