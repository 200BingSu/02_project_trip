import{j as t,O as e}from"./index-C02P6yB2.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
