import{F as t}from"./index-C02P6yB2.js";const o=t({key:"scrapAtom",default:{tripReviewId:0,copyTripId:0,newStartAt:"",newEndAt:""}});export{o as s};
