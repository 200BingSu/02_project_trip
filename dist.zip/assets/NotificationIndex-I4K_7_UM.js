import{j as t}from"./index-1BZ_akOR.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
