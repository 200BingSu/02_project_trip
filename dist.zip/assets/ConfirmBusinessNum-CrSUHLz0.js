import{j as s}from"./index-BDvp6vJ-.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
