import{j as e}from"./index-C6bOqW8w.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
