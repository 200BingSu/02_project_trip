import{j as s}from"./index-CCfEkYYD.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
