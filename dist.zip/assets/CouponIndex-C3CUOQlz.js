import{j as o}from"./index-D8wcWfn5.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
