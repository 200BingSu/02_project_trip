import{j as o}from"./index-C02P6yB2.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
