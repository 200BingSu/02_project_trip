import{j as o}from"./index-DNO2HYmg.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
