const e=o=>{o.current.scrollIntoView({behavior:"smooth"})};export{e as m};
