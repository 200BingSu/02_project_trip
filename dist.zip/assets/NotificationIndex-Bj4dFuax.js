import{j as t}from"./index-CPxdPWqf.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
