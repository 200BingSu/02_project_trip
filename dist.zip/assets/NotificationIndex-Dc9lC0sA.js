import{j as t}from"./index-CCfEkYYD.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
