import{j as t,O as s}from"./index-C6bOqW8w.js";const r=()=>t.jsx("div",{children:t.jsx(s,{})});export{r as default};
