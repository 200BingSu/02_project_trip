import{e,f as r}from"./index-DNO2HYmg.js";const i=e({key:"userAtom",default:{userId:0,email:"",name:"",profilePic:"",accessToken:"",providerType:r.LOCAL,role:[],tell:"",birth:""}});export{i as u};
