import{j as t}from"./index-scJjHvO6.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
