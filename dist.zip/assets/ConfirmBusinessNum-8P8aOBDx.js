import{j as s}from"./index-lSgSIVq0.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
