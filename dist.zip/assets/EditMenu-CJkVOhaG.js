import{j as t}from"./index-BDvp6vJ-.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
