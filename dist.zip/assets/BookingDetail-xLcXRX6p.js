import{j as o}from"./index-scJjHvO6.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
