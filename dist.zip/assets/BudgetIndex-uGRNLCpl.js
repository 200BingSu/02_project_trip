import{j as e}from"./index-lSgSIVq0.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
