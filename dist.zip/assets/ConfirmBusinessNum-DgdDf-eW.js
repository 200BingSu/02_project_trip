import{j as s}from"./index-Ci2k4qFh.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
