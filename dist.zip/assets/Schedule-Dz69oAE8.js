import{j as t,O as e}from"./index-C92yST0r.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
