import{j as e}from"./index-DyS74CsT.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
