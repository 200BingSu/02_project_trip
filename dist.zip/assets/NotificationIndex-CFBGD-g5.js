import{j as t}from"./index-Ci2k4qFh.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
