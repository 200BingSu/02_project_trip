import{j as t,O as s}from"./index-LV_9s5-1.js";const r=()=>t.jsx("div",{children:t.jsx(s,{})});export{r as default};
