import{p as t}from"./index-C92yST0r.js";const i=t({key:"editTripAtom",default:{title:"",startDate:"",endDate:"",nowUser:[],tripLocationList:[],from:"",isEdit:!1}});export{i as e};
