import{j as s}from"./index-1BZ_akOR.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
