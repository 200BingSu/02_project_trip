import{j as s}from"./index-CT_B22pp.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
