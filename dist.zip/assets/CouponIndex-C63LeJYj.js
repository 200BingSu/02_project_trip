import{j as o}from"./index-BDvp6vJ-.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
