import{j as t}from"./index-LV_9s5-1.js";const e=()=>t.jsx("div",{children:"StroeEdit"});export{e as default};
