import{j as s}from"./index-YXlYzo5D.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
