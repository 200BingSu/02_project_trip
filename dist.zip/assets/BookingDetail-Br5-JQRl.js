import{j as o}from"./index-Cwx4I7Vi.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
