import{j as t,O as e}from"./index-LV_9s5-1.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
