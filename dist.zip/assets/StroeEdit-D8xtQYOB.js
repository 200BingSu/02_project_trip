import{j as t}from"./index-C92yST0r.js";const e=()=>t.jsx("div",{children:"StroeEdit"});export{e as default};
