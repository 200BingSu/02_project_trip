import{j as s}from"./index-CGf2ioEP.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
