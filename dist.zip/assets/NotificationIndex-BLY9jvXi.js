import{j as t}from"./index-DlYLfxzI.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
