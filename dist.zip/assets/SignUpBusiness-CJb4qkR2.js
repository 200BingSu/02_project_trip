import{j as s}from"./index-BldMvkj-.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
