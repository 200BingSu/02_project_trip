import{j as s}from"./index-1BZ_akOR.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
