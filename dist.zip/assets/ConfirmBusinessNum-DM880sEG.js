import{j as s}from"./index-B4_CeF8a.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
