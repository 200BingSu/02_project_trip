import{m as o}from"./index-D8wcWfn5.js";const e=s=>{const[,,,,r]=o();return r?`${s}-css-var`:""};export{e as u};
