import{j as t,O as e}from"./index-D8wcWfn5.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
