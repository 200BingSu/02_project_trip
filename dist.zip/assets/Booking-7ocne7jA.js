import{j as t,O as s}from"./index-Cw-8d7Yh.js";const r=()=>t.jsx("div",{children:t.jsx(s,{})});export{r as default};
