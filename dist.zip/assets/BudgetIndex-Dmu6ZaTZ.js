import{j as e}from"./index-Cw-8d7Yh.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
