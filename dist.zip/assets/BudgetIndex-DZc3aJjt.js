import{j as e}from"./index-YXlYzo5D.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
