import{j as s}from"./index-ztVTG9lp.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
