import{j as e}from"./index-Cwx4I7Vi.js";const t=()=>e.jsx("div",{children:"CreateMenu"});export{t as default};
