import{j as e}from"./index-D8wcWfn5.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
