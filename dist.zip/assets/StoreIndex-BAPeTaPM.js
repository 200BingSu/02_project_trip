import{j as e}from"./index-Cwx4I7Vi.js";const t=()=>e.jsx("div",{children:"StoreIndex"});export{t as default};
