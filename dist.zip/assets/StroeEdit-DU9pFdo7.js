import{j as t}from"./index-scJjHvO6.js";const e=()=>t.jsx("div",{children:"StroeEdit"});export{e as default};
