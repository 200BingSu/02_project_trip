import{j as s}from"./index-CT_B22pp.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
