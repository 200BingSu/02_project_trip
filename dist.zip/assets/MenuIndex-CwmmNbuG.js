import{j as e}from"./index-Cwx4I7Vi.js";const r=()=>e.jsx("div",{children:"MenuIndex"});export{r as default};
