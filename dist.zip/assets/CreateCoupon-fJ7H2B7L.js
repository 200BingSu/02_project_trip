import{j as e}from"./index-Cwx4I7Vi.js";const r=()=>e.jsx("div",{children:"CreateCoupon"});export{r as default};
