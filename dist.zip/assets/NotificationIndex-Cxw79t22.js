import{j as t}from"./index-BDvp6vJ-.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
