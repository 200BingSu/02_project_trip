import{j as t,O as e}from"./index-CGf2ioEP.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
