import{j as t,O as e}from"./index-BDH47TWw.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
