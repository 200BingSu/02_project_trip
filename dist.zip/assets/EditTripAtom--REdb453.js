import{f as t}from"./index-B0MRRT76.js";const i=t({key:"editTripAtom",default:{title:"",startDate:"",endDate:"",nowUser:[],tripLocationList:[],from:"",isEdit:!1}});export{i as e};
