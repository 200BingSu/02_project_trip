import{j as s}from"./index-Cw-8d7Yh.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
