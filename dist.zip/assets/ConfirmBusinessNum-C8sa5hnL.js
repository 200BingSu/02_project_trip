import{j as s}from"./index-YXlYzo5D.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
