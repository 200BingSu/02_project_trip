import{j as o}from"./index-B4_CeF8a.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
