import{j as t,O as e}from"./index-H5Y2xFEd.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
