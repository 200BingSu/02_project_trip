import{j as s,O as t}from"./index-Cw-8d7Yh.js";const e=()=>s.jsx("div",{children:s.jsx(t,{})});export{e as default};
