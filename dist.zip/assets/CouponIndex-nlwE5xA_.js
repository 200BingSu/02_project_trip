import{j as o}from"./index-CGf2ioEP.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
