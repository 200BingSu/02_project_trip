import{j as o}from"./index-H5Y2xFEd.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
