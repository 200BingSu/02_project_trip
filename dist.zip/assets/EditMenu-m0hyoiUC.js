import{j as t}from"./index-LV_9s5-1.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
