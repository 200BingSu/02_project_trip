import{j as s}from"./index-DZF_lMwV.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
