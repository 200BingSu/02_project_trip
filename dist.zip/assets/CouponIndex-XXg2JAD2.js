import{j as o}from"./index-BldMvkj-.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
