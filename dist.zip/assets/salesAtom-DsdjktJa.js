import{f as s}from"./index-BDvp6vJ-.js";const e=s({key:"salesAtom",default:{sumMonth1:"0"}});export{e as s};
