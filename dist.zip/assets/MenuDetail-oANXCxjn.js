import{j as e}from"./index-B0MRRT76.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
