import{j as t,O as e}from"./index-CCfEkYYD.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
