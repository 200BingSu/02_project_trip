import{j as o}from"./index-C92yST0r.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
