import{j as o}from"./index-B0MRRT76.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
