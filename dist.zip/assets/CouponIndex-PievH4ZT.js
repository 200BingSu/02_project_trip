import{j as o}from"./index-C6bOqW8w.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
