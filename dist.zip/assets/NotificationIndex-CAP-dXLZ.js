import{j as t}from"./index-B4_CeF8a.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
