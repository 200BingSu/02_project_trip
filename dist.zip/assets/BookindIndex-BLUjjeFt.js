import{j as o}from"./index-scJjHvO6.js";const d=()=>o.jsx("div",{children:"BookindIndex"});export{d as default};
