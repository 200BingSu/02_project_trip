import{j as t,O as e}from"./index-C6bOqW8w.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
