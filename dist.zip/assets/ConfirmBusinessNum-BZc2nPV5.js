import{j as s}from"./index-H5Y2xFEd.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
