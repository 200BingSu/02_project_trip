import{j as o}from"./index-BDvp6vJ-.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
