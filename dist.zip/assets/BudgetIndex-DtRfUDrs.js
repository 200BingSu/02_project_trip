import{j as e}from"./index-H5Y2xFEd.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
