import{j as s}from"./index-CGf2ioEP.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
