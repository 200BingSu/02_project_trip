import{j as o}from"./index-Cwx4I7Vi.js";const d=()=>o.jsx("div",{children:"BookindIndex"});export{d as default};
