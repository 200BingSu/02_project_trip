import{j as o}from"./index-BntdmLw6.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
