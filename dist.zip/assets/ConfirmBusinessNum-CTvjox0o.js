import{j as s}from"./index-CXgPt5JN.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
