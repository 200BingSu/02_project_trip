import{j as e}from"./index-LV_9s5-1.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
