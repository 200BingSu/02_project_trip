import{j as s}from"./index-C92yST0r.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
