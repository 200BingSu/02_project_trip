import{j as o}from"./index-Ci2k4qFh.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
