import{e}from"./index-DNO2HYmg.js";const o=e({key:"tripAtom",default:{nowTripId:0,day:1,lastSeq:0,prevScheName:"",prevSchelat:0,prevSchelng:0,nowName:"",nowLat:0,nowLng:0}});export{o as t};
