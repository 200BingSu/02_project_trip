import{r as t}from"./index-CXgPt5JN.js";function c(){const[,e]=t.useReducer(r=>r+1,0);return e}export{c as u};
