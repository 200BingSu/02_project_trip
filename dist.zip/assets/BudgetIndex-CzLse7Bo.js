import{j as e}from"./index-LV_9s5-1.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
