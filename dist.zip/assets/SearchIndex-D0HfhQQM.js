import{j as t,O as e}from"./index-Cw-8d7Yh.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
