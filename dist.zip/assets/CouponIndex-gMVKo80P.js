import{j as o}from"./index-lSgSIVq0.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
