import{j as e}from"./index-BDvp6vJ-.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
