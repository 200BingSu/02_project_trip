import{h as a}from"./index-BldMvkj-.js";const r=a({key:"searchAtom",default:{searchWord:"",searchData:[],start_idx:0,category:0}});export{r as s};
