import{j as s}from"./index-C6bOqW8w.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
