import{j as t}from"./index-B0MRRT76.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
