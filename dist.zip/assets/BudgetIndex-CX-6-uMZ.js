import{j as e}from"./index-C92yST0r.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
