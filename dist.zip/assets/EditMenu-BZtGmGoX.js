import{j as t}from"./index-C92yST0r.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
