import{F as t}from"./index-C02P6yB2.js";const i=t({key:"editTripAtom",default:{title:"",startDate:"",endDate:"",nowUser:[],tripLocationList:[],from:"",isEdit:!1}});export{i as e};
