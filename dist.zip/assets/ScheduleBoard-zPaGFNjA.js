import{j as t,O as e}from"./index-C92yST0r.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
