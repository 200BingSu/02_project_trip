import{e,f as r}from"./index-Cw-8d7Yh.js";const i=e({key:"userAtom",default:{userId:0,email:"",name:"",profilePic:"",accessToken:"",providerType:r.LOCAL,role:[],tell:"",birth:""}});export{i as u};
