import{j as t}from"./index-YXlYzo5D.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
