import{f as s}from"./index-LV_9s5-1.js";const e=s({key:"salesAtom",default:{sumMonth1:"0"}});export{e as s};
