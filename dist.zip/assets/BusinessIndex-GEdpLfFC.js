import{j as s}from"./index-Ci2k4qFh.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
