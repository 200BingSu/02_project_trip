import{j as s}from"./index-scJjHvO6.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
