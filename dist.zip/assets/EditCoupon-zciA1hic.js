import{j as o}from"./index-Cwx4I7Vi.js";const r=()=>o.jsx("div",{children:"EditCoupon"});export{r as default};
