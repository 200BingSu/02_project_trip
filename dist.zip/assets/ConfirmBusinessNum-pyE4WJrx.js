import{j as s}from"./index-LV_9s5-1.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
