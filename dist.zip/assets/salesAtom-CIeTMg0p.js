import{f as s}from"./index-B0MRRT76.js";const e=s({key:"salesAtom",default:{sumMonth1:"0"}});export{e as s};
