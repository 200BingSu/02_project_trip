import{j as t}from"./index-Cwx4I7Vi.js";const e=()=>t.jsx("div",{children:"StroeEdit"});export{e as default};
