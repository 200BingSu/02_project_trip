import{j as t}from"./index-B0MRRT76.js";const e=()=>t.jsx("div",{children:"StroeEdit"});export{e as default};
