import{j as t,O as r}from"./index-Cwx4I7Vi.js";const e=()=>t.jsx("div",{children:t.jsx(r,{})});export{e as default};
