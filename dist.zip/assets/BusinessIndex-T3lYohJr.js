import{j as s}from"./index-H5Y2xFEd.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
