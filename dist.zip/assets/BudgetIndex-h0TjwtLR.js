import{j as e}from"./index-1BZ_akOR.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
