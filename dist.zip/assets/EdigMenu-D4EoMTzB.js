import{j as e}from"./index-Cwx4I7Vi.js";const t=()=>e.jsx("div",{children:"EdigMenu"});export{t as default};
