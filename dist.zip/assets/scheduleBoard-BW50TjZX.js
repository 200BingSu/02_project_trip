import{j as t,O as e}from"./index-Ci2k4qFh.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
