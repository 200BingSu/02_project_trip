import{j as t,O as e}from"./index-LV_9s5-1.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
