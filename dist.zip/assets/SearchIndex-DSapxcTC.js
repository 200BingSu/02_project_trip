import{j as t,O as e}from"./index-DNO2HYmg.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
