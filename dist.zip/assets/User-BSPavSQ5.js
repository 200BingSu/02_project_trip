import{j as s,O as t}from"./index-Cwx4I7Vi.js";const e=()=>s.jsx("div",{children:s.jsx(t,{})});export{e as default};
