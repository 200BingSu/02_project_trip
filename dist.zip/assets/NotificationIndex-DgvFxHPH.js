import{j as t}from"./index-Cw-8d7Yh.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
