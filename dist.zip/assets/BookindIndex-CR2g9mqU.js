import{j as o}from"./index-C92yST0r.js";const d=()=>o.jsx("div",{children:"BookindIndex"});export{d as default};
