import{p as e}from"./index-C92yST0r.js";const p=e({key:"tripAtom",default:{nowTripId:0,day:1,lastSeq:0,prevScheName:"",prevSchelat:"",prevSchelng:""}});export{p as t};
