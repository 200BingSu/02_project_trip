import{j as t}from"./index-CXgPt5JN.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
