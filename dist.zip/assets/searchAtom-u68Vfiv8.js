import{i as a}from"./index-C6bOqW8w.js";const s=a({key:"searchAtom",default:{searchWord:"",searchData:[],lastIndex:0}});export{s};
