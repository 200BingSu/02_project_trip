import{j as e}from"./index-C92yST0r.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
