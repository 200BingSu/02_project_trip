import{j as s}from"./index-D8wcWfn5.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
