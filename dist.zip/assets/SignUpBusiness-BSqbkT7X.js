import{j as s}from"./index-CCfEkYYD.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
