import{j as t}from"./index-DyS74CsT.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
