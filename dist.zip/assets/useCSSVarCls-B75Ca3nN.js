import{e}from"./index-BDH47TWw.js";const a=s=>{const[,,,,r]=e();return r?`${s}-css-var`:""};export{a as u};
