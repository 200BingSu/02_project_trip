import{j as o}from"./index-B0MRRT76.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
