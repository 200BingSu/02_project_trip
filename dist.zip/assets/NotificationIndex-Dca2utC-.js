import{j as t}from"./index-LV_9s5-1.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
