import{j as s}from"./index-CCfEkYYD.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
