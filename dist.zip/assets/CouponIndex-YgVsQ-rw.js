import{j as o}from"./index-1BZ_akOR.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
