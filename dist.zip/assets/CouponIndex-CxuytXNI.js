import{j as o}from"./index-DZF_lMwV.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
