import{j as o}from"./index-LV_9s5-1.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
