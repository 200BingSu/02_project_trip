import{j as e}from"./index-Ds_Uuw_l.js";const t=()=>e.jsx("div",{children:"CreateMenu"});export{t as default};
