import{j as e}from"./index-V20l1Fvl.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
