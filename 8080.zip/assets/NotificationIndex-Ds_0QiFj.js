import{j as t}from"./index-V20l1Fvl.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
