import{j as t}from"./index-BE7VYVOv.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
