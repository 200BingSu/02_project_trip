import{j as s,O as t}from"./index-BE7VYVOv.js";const e=()=>s.jsx("div",{children:s.jsx(t,{})});export{e as default};
