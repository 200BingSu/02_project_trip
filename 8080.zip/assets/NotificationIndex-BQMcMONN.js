import{j as t}from"./index-Ds_Uuw_l.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
