import{j as o}from"./index-V20l1Fvl.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
