import{j as e}from"./index-Ds_Uuw_l.js";const r=()=>e.jsx("div",{children:"CreateCoupon"});export{r as default};
