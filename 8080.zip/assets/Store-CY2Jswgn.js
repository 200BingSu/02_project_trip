import{j as t,O as r}from"./index-Ds_Uuw_l.js";const e=()=>t.jsx("div",{children:t.jsx(r,{})});export{e as default};
