import{j as e}from"./index-Ds_Uuw_l.js";const t=()=>e.jsx("div",{children:"ReviewIndex"});export{t as default};
