import{j as e}from"./index-Ds_Uuw_l.js";const i=()=>e.jsx("div",{children:"EditReview"});export{i as default};
