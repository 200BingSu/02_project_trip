import{j as s}from"./index-V20l1Fvl.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
