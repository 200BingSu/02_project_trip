import{j as o}from"./index-Ds_Uuw_l.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
