import{j as o}from"./index-Ds_Uuw_l.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
