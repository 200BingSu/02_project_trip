import{j as e}from"./index-Ds_Uuw_l.js";const r=()=>e.jsx("div",{children:"MenuIndex"});export{r as default};
