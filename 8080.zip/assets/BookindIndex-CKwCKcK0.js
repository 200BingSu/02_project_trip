import{j as o}from"./index-Ds_Uuw_l.js";const d=()=>o.jsx("div",{children:"BookindIndex"});export{d as default};
