import{j as s,O as t}from"./index-Ds_Uuw_l.js";const r=()=>s.jsx("div",{className:"w-full",children:s.jsx(t,{})});export{r as default};
