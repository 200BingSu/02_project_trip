import{j as o}from"./index-Ds_Uuw_l.js";const r=()=>o.jsx("div",{children:"EditCoupon"});export{r as default};
