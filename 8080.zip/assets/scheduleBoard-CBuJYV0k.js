import{j as t,O as e}from"./index-V20l1Fvl.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
