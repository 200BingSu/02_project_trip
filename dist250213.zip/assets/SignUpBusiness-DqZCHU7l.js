import{j as s}from"./index-vPyaWLeP.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
