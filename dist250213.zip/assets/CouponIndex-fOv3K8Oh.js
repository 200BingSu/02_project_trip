import{j as o}from"./index-vPyaWLeP.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
