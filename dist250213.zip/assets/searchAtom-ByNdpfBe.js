import{i as e}from"./index-vPyaWLeP.js";const r=e({key:"searchAtom",default:{searchWord:""}});export{r as s};
