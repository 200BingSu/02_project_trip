const Trips = () => {
  return <div>Trips</div>;
};
export default Trips;
