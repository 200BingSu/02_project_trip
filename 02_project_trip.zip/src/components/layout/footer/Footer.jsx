const Footer = () => {
  return <div className="max-w-3xl mx-auto">Footer</div>;
};
export default Footer;
