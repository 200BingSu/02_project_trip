const Header = () => {
  return <div className="max-w-3xl mx-auto">Header</div>;
};
export default Header;
