const DaysExtraFooter = () => {
  return (
    <div>
      <button type="button">초기화</button>
      <button type="button">일정등록</button>
    </div>
  );
};
export default DaysExtraFooter;
