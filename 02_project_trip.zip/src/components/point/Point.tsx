import { useRef } from "react";
import { AiOutlineScan } from "react-icons/ai";
import TitleHeaderTs from "../layout/header/TitleHeaderTs";

interface PointProps {
  handleClose?: () => void;
}
const Point = ({ handleClose }: PointProps): JSX.Element => {
  const fileInputRef = useRef(null);

  const openCamera = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  return (
    <div className="max-w-[768px] w-full h-screen fixed top-0 left-1/2 -translate-x-1/2 bg-white z-50">
      <TitleHeaderTs icon="close" title="포인트 결제" onClick={handleClose} />
      <div className="relative ">
        {!qrResult ? (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full "
            />
            <div className="absolute top-20 left-10 w-10 h-10 rounded-tl-xl border-t-4 border-l-4 border-primary"></div>
            <div className="absolute top-20 right-10 w-10 h-10 rounded-tr-xl border-t-4 border-r-4 border-primary"></div>
            <div className="absolute bottom-40 left-10 w-10 h-10 rounded-bl-xl border-b-4 border-l-4 border-primary"></div>
            <div className="absolute bottom-40 right-10 w-10 h-10 rounded-br-xl   border-b-4 border-r-4 border-primary"></div>
          </>
        ) : (
          <h3>📌 QR 코드 결과: {qrResult}</h3>
        )}
        <div className="flex flex-col justify-center items-center mt-6 gap-1">
          <AiOutlineScan className="text-2xl text-slate-400 mr-1" />
          <p className="text-slate-700 text-base">
            <b>QR코드</b>를 촬영해주세요
          </p>
        </div>
      </div>
    </div>
  );
};

export default Point;
