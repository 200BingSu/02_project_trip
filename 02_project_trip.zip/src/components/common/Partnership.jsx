import React from "react";

const Partnership = () => {
  return (
    <div className="h-[14px] px-[5px] py-[3px] bg-[#FDB4A1] bg-opacity-50 text-secondary3_3 text-[8px] font-semibold flex items-center justify-center line-height-[100%]">
      지역 제휴
    </div>
  );
};

export default Partnership;
