export const bookingMock = [
  {
    bookingId: "1",
    strfId: "4",
    title: "제우스모텔",
    picName: "1.webp",
    totalPayment: 60000,
    state: "0",
    checkInDate: "2025-03-11 화",
    checkOutDate: "2025-03-15 토",
    checkInTime: "14:00",
    checkOutTime: "21:00",
  },
];
