export const busiPointMock = {
  totalAmount: 10000,
  pointDetails: [
    {
      strfId: 4,
      menuId: 1,
      title: "싱글룸",
      amount: 5000,
      usedAt: "2025-03-06 10:03:48",
      refund: true,
    },
    {
      strfId: 4,
      menuId: 3,
      title: "패밀리룸",
      amount: 10000,
      usedAt: "2025-03-06 20:17:49",
      refund: false,
    },
  ],
};
