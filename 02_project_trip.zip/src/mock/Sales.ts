export const mockSalesData = [
  {
    month: "2024-04",
    totalSales: 150000,
  },
  {
    month: "2024-05",
    totalSales: 60000,
  },
  {
    month: "2024-06",
    totalSales: 150000,
  },
  {
    month: "2024-07",
    totalSales: 60000,
  },
  {
    month: "2024-08",
    totalSales: 40000,
  },
  {
    month: "2024-09",
    totalSales: 100000,
  },
  {
    month: "2024-10",
    totalSales: 70000,
  },
  {
    month: "2024-11",
    totalSales: 80000,
  },
  {
    month: "2024-12",
    totalSales: 50000,
  },
  {
    month: "2025-01",
    totalSales: 100000,
  },
  {
    month: "2025-02",
    totalSales: 90000,
  },
  {
    month: "2025-03",
    totalSales: 180000,
  },
];
