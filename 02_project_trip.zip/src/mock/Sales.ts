export const salesMockData = {
  month1: 0,
  month2: 1000000,
  month3: 100000,
  month4: 2000000,
  month5: 8000000,
  month6: 12000000,
  month7: 7000000,
  month8: 9000000,
  month9: 15000000,
  month10: 6000000,
  month11: 11000000,
  month12: 4000000,
};
