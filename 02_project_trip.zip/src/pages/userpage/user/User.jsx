import { Outlet } from "react-router-dom";

const User = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default User;
