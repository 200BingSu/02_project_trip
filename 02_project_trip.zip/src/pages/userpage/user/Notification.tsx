const Notification = (): JSX.Element => {
  return <div>Notification</div>;
};

export default Notification;
