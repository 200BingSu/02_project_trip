import { Outlet } from "react-router-dom";

const Schedule = () => {
  return <div>{<Outlet />}</div>;
};
export default Schedule;
