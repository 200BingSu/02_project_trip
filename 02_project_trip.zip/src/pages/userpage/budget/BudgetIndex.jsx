const BudgetIndex = () => {
  return <div>BudgetIndex</div>;
};
export default BudgetIndex;
