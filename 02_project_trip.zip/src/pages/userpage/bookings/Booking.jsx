import { Outlet } from "react-router-dom";

const Booking = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};
export default Booking;
