import { Outlet } from "react-router-dom";

const SignUp = () => {
  return <div className="w-full">{<Outlet />}</div>;
};
export default SignUp;
