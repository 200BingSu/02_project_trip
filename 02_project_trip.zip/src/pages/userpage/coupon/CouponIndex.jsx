const CouponIndex = () => {
  return <div>CouponIndex</div>;
};
export default CouponIndex;
