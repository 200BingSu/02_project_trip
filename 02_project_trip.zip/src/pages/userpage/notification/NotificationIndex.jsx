const NotificationIndex = () => {
  return <div>NotificationIndex</div>;
};
export default NotificationIndex;
