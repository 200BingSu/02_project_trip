import { Outlet } from "react-router-dom";

const ScheduleBoard = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};
export default ScheduleBoard;
