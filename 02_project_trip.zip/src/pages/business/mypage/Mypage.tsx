import { Outlet } from "react-router-dom";

const Mypage = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Mypage;
