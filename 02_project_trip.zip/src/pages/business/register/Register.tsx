import { Outlet } from "react-router-dom";

const Register = (): JSX.Element => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Register;
