const StroeEdit = (): JSX.Element => {
  return <div>StroeEdit</div>;
};

export default StroeEdit;
