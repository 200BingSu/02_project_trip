const BookindIndex = (): JSX.Element => {
  return <div>BookindIndex</div>;
};

export default BookindIndex;
