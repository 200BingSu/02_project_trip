const BookingDetail = (): JSX.Element => {
  return <div>BookingDetail</div>;
};

export default BookingDetail;
