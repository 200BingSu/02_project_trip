const EditMenu = (): JSX.Element => {
  return <div>EditMenu</div>;
};

export default EditMenu;
