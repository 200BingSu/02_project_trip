const MenuDetail = (): JSX.Element => {
  return <div>MenuDetail</div>;
};

export default MenuDetail;
