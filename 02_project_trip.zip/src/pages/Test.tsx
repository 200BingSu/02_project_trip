(window as any).global = window;

const Test = () => {
  return <div>test</div>;
};

export default Test;
