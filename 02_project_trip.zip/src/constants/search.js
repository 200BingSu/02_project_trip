// 카테고리 배열 (전체=null)
export const categoryArr = [
  { type: "ALL", name: "전체" },
  { type: "TOUR", name: "관광지" },
  { type: "STAY", name: "숙소" },
  { type: "RESTAUR", name: "맛집" },
  { type: "FEST", name: "축제" },
];
// 정렬 배열
export const orderTypeArr = [
  { type: "ratingAvg", name: "평점순" },
  { type: "ratingCnt", name: "리뷰순" },
  { type: "likeCnt", name: "좋아요순" },
];
//2025-02-01
