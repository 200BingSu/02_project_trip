import{r as t}from"./index-C93OXIGC.js";function c(){const[,e]=t.useReducer(r=>r+1,0);return e}export{c as u};
