import{R as e}from"./index-C93OXIGC.js";const r=e({key:"tripAtom",default:{nowTripId:0,day:1,lastSeq:0,prevScheName:"",prevSchelat:"",prevSchelng:""}});export{r as t};
