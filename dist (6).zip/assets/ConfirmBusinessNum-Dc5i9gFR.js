import{j as s}from"./index-C93OXIGC.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
