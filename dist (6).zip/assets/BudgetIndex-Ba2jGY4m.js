import{j as e}from"./index-C93OXIGC.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
