import{j as s}from"./index-BimvysYt.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
