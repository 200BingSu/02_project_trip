import{j as t,O as e}from"./index-Ca8m4nba.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
