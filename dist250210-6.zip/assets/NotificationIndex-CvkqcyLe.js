import{j as t}from"./index-Ca8m4nba.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
