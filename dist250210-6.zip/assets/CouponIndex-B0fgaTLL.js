import{j as o}from"./index-Ca8m4nba.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
