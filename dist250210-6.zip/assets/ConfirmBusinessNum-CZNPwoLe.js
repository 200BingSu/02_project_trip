import{j as s}from"./index-Ca8m4nba.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
