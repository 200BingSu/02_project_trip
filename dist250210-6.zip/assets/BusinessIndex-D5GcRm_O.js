import{j as s}from"./index-Ca8m4nba.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
