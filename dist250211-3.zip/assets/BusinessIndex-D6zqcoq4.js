import{j as s}from"./index-qnqcAXnW.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
