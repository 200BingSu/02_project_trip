import{R as t}from"./index-BGgYyMzG.js";const i=t({key:"editTripAtom",default:{title:"",startDate:"",endDate:"",nowUser:[],tripLocationList:[],from:"",isEdit:!1}});export{i as e};
