import{j as s,O as t}from"./index-BGgYyMzG.js";const r=()=>s.jsx("div",{className:"w-full",children:s.jsx(t,{})});export{r as default};
