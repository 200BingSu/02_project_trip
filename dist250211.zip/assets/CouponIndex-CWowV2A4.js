import{j as o}from"./index-y1wEQpfK.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
