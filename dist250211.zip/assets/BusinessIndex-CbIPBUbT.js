import{j as s}from"./index-y1wEQpfK.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
