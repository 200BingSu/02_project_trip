import{j as t,O as e}from"./index-D0MEwewf.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
