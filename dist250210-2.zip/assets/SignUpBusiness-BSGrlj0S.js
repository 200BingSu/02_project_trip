import{j as s}from"./index-D0MEwewf.js";const n=()=>s.jsx("div",{children:"SignUpBusiness"});export{n as default};
