import{j as s}from"./index-D0MEwewf.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
