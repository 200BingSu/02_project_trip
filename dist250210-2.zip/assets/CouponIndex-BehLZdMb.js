import{j as o}from"./index-D0MEwewf.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
