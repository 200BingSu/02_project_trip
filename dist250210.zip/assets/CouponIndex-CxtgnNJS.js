import{j as o}from"./index-DyHKvFXx.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
