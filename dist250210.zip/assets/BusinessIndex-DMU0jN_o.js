import{j as s}from"./index-DyHKvFXx.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
