import{j as t,O as e}from"./index-DyHKvFXx.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
