import{j as o}from"./index-hzpou2jK.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
