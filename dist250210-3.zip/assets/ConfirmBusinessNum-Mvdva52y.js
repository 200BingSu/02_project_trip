import{j as s}from"./index-hzpou2jK.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
