import{j as t,O as e}from"./index-hzpou2jK.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
