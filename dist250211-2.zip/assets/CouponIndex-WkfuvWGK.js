import{j as o}from"./index-bTpIIdkl.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
