import{j as s}from"./index-bTpIIdkl.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
