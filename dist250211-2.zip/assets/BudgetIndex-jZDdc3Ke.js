import{j as e}from"./index-bTpIIdkl.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
