import{i as e}from"./index-DB3eQjaF.js";const r=e({key:"searchAtom",default:{searchWord:""}});export{r as s};
