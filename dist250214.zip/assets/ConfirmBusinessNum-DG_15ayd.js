import{j as s}from"./index-DB3eQjaF.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
