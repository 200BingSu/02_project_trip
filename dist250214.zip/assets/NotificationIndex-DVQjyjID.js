import{j as t}from"./index-DB3eQjaF.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
