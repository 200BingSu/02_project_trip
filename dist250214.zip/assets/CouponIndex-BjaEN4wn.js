import{j as o}from"./index-DB3eQjaF.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
