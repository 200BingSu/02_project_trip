import{j as t,O as e}from"./index-CiM0iehI.js";const r=()=>t.jsx("div",{children:t.jsx(e,{})});export{r as default};
