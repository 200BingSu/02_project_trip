import{R as t}from"./index-CiM0iehI.js";const i=t({key:"editTripAtom",default:{title:"",startDate:"",endDate:"",nowUser:[],tripLocationList:[],from:"",isEdit:!1}});export{i as e};
