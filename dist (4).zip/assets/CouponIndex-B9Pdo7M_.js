import{j as o}from"./index-CiM0iehI.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
