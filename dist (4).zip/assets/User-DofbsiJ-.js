import{j as s,O as t}from"./index-CiM0iehI.js";const e=()=>s.jsx("div",{children:s.jsx(t,{})});export{e as default};
