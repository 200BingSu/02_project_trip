import{j as t}from"./index-CiM0iehI.js";const o=()=>t.jsx("div",{children:"NotificationIndex"});export{o as default};
