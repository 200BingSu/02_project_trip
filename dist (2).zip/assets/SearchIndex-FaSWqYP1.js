import{j as t,O as e}from"./index-BD3RHMps.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
