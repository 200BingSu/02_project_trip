import{j as s}from"./index-WSm8V2ST.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
