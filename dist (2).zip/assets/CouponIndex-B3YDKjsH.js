import{j as o}from"./index-B-t7JaaM.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
