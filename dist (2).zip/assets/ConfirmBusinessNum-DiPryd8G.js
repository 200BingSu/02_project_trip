import{j as s}from"./index-BD3RHMps.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
