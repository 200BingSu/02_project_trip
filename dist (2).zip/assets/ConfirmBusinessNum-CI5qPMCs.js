import{j as s}from"./index-Bm9G2PMV.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
