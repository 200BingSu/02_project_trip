import{j as s}from"./index-BsLiJZW6.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
