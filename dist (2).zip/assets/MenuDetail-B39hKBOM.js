import{j as e}from"./index-Bm9G2PMV.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
