import{j as o}from"./index-BsLiJZW6.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
