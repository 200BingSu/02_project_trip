import{j as t,O as e}from"./index-B-t7JaaM.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
