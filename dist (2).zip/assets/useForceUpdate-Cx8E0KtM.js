import{r as t}from"./index-cNNjOFrG.js";function c(){const[,e]=t.useReducer(r=>r+1,0);return e}export{c as u};
