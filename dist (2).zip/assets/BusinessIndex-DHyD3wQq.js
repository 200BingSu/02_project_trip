import{j as s}from"./index-BsLiJZW6.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
