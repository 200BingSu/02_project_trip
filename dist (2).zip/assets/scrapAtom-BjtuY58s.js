import{e as t}from"./index-BD3RHMps.js";const o=t({key:"scrapAtom",default:{tripReviewId:0,copyTripId:0,newStartAt:"",newEndAt:""}});export{o as s};
