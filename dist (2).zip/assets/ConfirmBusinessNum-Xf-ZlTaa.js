import{j as s}from"./index-cNNjOFrG.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
