import{j as e}from"./index-BD3RHMps.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
