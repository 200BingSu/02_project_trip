import{j as o}from"./index-Bm9G2PMV.js";const i=()=>o.jsx("div",{children:"BookingDetail"});export{i as default};
