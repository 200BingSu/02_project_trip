import{j as t}from"./index-B-t7JaaM.js";const r=()=>t.jsx("div",{children:"EditMenu"});export{r as default};
