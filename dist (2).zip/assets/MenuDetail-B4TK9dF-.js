import{j as e}from"./index-B-t7JaaM.js";const r=()=>e.jsx("div",{children:"MenuDetail"});export{r as default};
