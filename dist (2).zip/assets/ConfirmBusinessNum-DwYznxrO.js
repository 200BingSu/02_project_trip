import{j as s}from"./index-fkRlkcwr.js";const i=()=>s.jsx("div",{children:"ConfirmBusinessNum"});export{i as default};
