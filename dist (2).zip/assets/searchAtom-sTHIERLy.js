import{f as e}from"./index-Bm9G2PMV.js";const t=e({key:"searchAtom",default:{searchWord:"",searchData:[],start_idx:0,category:0,amenityId:[],orderType:0,more:!0,count:0}});export{t as s};
