import{j as o}from"./index-Bm9G2PMV.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
