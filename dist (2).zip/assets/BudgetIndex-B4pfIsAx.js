import{j as e}from"./index-Bm9G2PMV.js";const d=()=>e.jsx("div",{children:"BudgetIndex"});export{d as default};
