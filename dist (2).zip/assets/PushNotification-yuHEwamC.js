import{u as s,j as t,T as a}from"./index-B-t7JaaM.js";const o=()=>{const i=s();return t.jsx("div",{children:t.jsx(a,{title:"알림",icon:"back",onClick:()=>i("/")})})};export{o as default};
