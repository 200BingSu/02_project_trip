import{j as o}from"./index-WSm8V2ST.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
