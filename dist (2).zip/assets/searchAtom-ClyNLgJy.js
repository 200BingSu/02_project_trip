import{e}from"./index-BD3RHMps.js";const o=e({key:"searchAtom",default:{searchData:[],start_idx:0,category:0,amenityId:[],orderType:0,more:!0,count:0,fromContent:!1}});export{o as s};
