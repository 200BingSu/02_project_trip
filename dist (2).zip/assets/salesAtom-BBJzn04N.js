import{f as s}from"./index-Bm9G2PMV.js";const e=s({key:"salesAtom",default:{sumMonth1:"0"}});export{e as s};
