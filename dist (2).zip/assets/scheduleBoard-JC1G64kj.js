import{j as t,O as e}from"./index-WSm8V2ST.js";const s=()=>t.jsx("div",{children:t.jsx(e,{})});export{s as default};
