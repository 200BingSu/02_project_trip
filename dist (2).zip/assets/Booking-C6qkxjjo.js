import{j as t,O as s}from"./index-WSm8V2ST.js";const r=()=>t.jsx("div",{children:t.jsx(s,{})});export{r as default};
