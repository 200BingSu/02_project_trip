import{j as o}from"./index-B-t7JaaM.js";const d=()=>o.jsx("div",{children:"BookindIndex"});export{d as default};
