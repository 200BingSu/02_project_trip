import{j as o}from"./index-cNNjOFrG.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
