import{j as s}from"./index-xgrFPZPY.js";const n=()=>s.jsx("div",{children:"BusinessIndex"});export{n as default};
