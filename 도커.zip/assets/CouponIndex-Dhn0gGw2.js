import{j as o}from"./index-xgrFPZPY.js";const e=()=>o.jsx("div",{children:"CouponIndex"});export{e as default};
